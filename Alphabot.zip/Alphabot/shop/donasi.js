const donasibot = () => {
return `DONASI BISA VIA BANK / E-MONEY


*💰 E-MONEY*

1. DANA
	ㅁ 0813 9353 7724
	
atas nama ZeusXz
`
	}

exports.donasibot = donasibot
 