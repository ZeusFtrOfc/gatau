const list_sausage = (prefix) => {
return `*ZEUSXZ STORE*
	
PROSES	1-60Mnt Max 1X24 Jam		
OPEN	09.00-21.00		
FORMAT	ID		
			
CANDY SAUSAGE			
	
60C	Rp 16,000.00		
180C	Rp 45,000.00		
316C	Rp 68,000.00		
718C	Rp 135,000.00		
1.368C	Rp 265,000.00		
2.118C	Rp 418,000.00		
3.548C	Rp 682,000.00		
7.096C	Rp 1.305,000.00		
			
Untuk pay / pembayan silahkan ketik ${prefix}pay
`
	}

exports.list_sausage = list_sausage

