// jangan di ubah jika tidak punya group bot, takutnya eror
const gcbotwa = () =>{
	return`Join Aja Semua Fitur Bot Bisa Digunakan !

1. *ZeusXzBot Support*
_https://chat.whatsapp.com/EQWM0ZQZPJRHuNe8yuqRlS_
Jika ada link yang ke reset, silahkan hubungi
owner untuk meminta link yang baru
`
}
exports.gcbotwa = gcbotwa