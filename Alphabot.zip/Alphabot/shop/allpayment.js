const allpayment = (prefix) => {
return `PAYMENT BY ZEUSXZ STORE
	
*💰 E-MONEY*


1. DANA
	ㅁ 081393537724

*📲 PULSA*

Tidak tersedia
	
Sebelum melakukan pembayaran ada baiknya anda menghubungi owner terlebih dahulu!
`
	}

exports.allpayment = allpayment
 